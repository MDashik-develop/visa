<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Website Content')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="bg-white rounded-lg shadow p-6">
        <form action="<?php echo e(route('admin.slider.update', $slider->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        
            <!-- Title -->
            <div>
                <label class="block font-medium">Title</label>
                <input type="text" name="title" value="<?php echo e(old('title', $slider->title)); ?>" class="w-full border rounded p-2">
            </div>
        
            <!-- Description -->
            <div>
                <label class="block font-medium">Description</label>
                <textarea name="description" class="w-full border rounded p-2"><?php echo e(old('description', $slider->description)); ?></textarea>
            </div>

            <!-- Status -->
            <div class="mb-4">
                <label for="status" class="block text-gray-700">Status</label>
                <select name="status" id="status"
                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="1" <?php echo e($slider->status == 1 ? 'selected' : ''); ?>>Active</option>
                    <option value="0" <?php echo e($slider->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
        
            <!-- Image -->
            <div>
                <label class="block font-medium">Image</label>
                <input type="file" name="image" class="w-full border rounded p-2">
                <small class="text-gray-500 block mb-2">Recommended size: 1920 × 858px</small>
                <?php if($slider->image): ?>
                    <img src="<?php echo e(asset('storage/' . $slider->image)); ?>" alt="Slider Image" class="mt-2 w-32">
                <?php endif; ?>
            </div>
        
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Slider</button>
        </form>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\ashik\visa\resources\views/backend/website/sliderEdit.blade.php ENDPATH**/ ?>