<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Website All')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!-- Visa Types Table -->
    <div class="bg-white rounded-lg shadow p-6">
        

        <form action="<?php echo e(route('admin.website.save')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6 bg-white p-6 rounded shadow">
            <?php echo csrf_field(); ?>

            <div>
                <label class="block font-medium">Website Name</label>
                <input type="text" name="name" value="<?php echo e(old('name', $website->name ?? '')); ?>" class="w-full border rounded p-2">
            </div>

            <div>
                <label class="block font-medium">Title</label>
                <input type="text" name="title" value="<?php echo e(old('title', $website->title ?? '')); ?>" class="w-full border rounded p-2">
            </div>

            <div>
                <label class="block font-medium">Description</label>
                <textarea name="description" class="w-full border rounded p-2"><?php echo e(old('description', $website->description ?? '')); ?></textarea>
            </div>

            <div>
                <label class="block font-medium">Address</label>
                <input type="text" name="address" value="<?php echo e(old('address', $website->address ?? '')); ?>" class="w-full border rounded p-2">
            </div>

            <div>
                <label class="block font-medium">Email</label>
                <input type="email" name="email" value="<?php echo e(old('email', $website->email ?? '')); ?>" class="w-full border rounded p-2">
            </div>

            <div>
                <label class="block font-medium">Phone</label>
                <input type="text" name="phone" value="<?php echo e(old('phone', $website->phone ?? '')); ?>" class="w-full border rounded p-2">
            </div>

            <div>
                <label class="block font-medium">Logo</label>
                <input type="file" name="logo" class="w-full border rounded p-2">
                <?php if(isset($website->logo)): ?>
                    <img src="<?php echo e(asset('storage/'.$website->logo)); ?>" alt="Logo" class="mt-2 w-32">
                <?php endif; ?>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Save Settings</button>
        </form>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\ashik\visa\resources\views/backend/website/index.blade.php ENDPATH**/ ?>