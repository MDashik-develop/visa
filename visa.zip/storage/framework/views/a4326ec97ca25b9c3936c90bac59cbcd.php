<svg class="h-6 w-6 text-gray-800" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12h15m0 0-6.75-6.75M19.5 12l-6.75 6.75"/>
</svg><?php /**PATH D:\ashik\visa\storage\framework\views/8259424b95b1aecde8aa8d0c913a3f32.blade.php ENDPATH**/ ?>