<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />


        <!-- FontAwesome Icons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

        <!-- Tooltip CSS -->
        <link rel="stylesheet" href="https://unpkg.com/tooltip.js/dist/tooltip.min.css">

        <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>



        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>

    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100 dark:bg-gray-900">
            
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="sm:ml-64">
         
               <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                  <!-- notifications news -->
                        <?php if(session('success') || $errors->any()): ?>
                            <div
                                    x-data="{ show: true }"
                                    x-init="setTimeout(() => show = false, 4000)"
                                    x-show="show"
                                    class="fixed top-5 right-5 z-50 px-6 py-4 rounded-md shadow-lg text-white transition-all duration-500"
                                    :class="{
                                        'bg-green-500': '<?php echo e(session('success') ? 'true' : 'false'); ?>' === 'true',
                                        'bg-red-500': '<?php echo e($errors->any() ? 'true' : 'false'); ?>' === 'true',
                                    }"
                                >
                                <?php if(session('success')): ?>
                                    <?php echo e(session('success')); ?>

                                <?php endif; ?>
            
                                <?php if($errors->any()): ?>
                                    <ul class="list-disc list-inside text-sm">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
         
         
               <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
         
                  <!-- Page Content -->
                  <main>
                     <?php echo e($slot); ?>

                  </main>

               </div>
         
            </div>
         </div>
    </body>
</html>
<?php /**PATH D:\ashik\visa\resources\views/layouts/app.blade.php ENDPATH**/ ?>